<?php
//definir constantes de archivos de texto para almacenar datos.
define('LIBROS_FILE', '../txt/libro.txt');
define('USUARIOS_FILE', '../txt/usuarios.txt');
define('PRESTAMOS_FILE', '../txt/prestamos.txt');

?>